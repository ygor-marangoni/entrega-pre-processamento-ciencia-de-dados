# Trabalho 4 — Regras de Associação Apriori

Este diretório será desenvolvido de forma sequencial, somente após autorização
expressa para cada etapa. O objetivo é identificar regras de associação entre
características de clientes pelo algoritmo Apriori do WEKA.

## Estado atual

- Etapa 0: auditoria concluída.
- Etapa 1: estrutura documental mínima criada.
- Etapa 2: análise exploratória dos 13 atributos concluída; a seleção dos oito
  atributos permanece pendente de aprovação.
- Etapa 3: proposta de discretização concluída, validada e autorizada para
  aplicação na Etapa 4.
- Etapa 4: base discretizada CSV e ARFF gerada e validada, com oito atributos
  nominais e 10.000 registros.
- Etapa 5: validação formal aprovada e frequências dos 27 itens calculadas.
- Etapa 6: opções do Apriori auditadas na instalação real do WEKA 3.8.7; não
  houve mineração de dados.
- Etapa 7: bloqueada antes dos testes, pois `-Z` trata o primeiro valor nominal
  de cada atributo como ausente na implementação instalada.
- Nenhuma base foi copiada, transformada, discretizada ou executada no WEKA.

## Fonte candidata confirmada na auditoria

`../trabalho_3_clusterizacao/data/amostras/base_amostra_10000_analise.csv`

A origem contém 10.000 registros e valores originais não ponderados, porém
preserva `ROW_ID_AMOSTRA`, `SK_ID_CURR` e `TARGET` apenas para rastreabilidade.
Essas colunas não poderão compor a futura base de Apriori.

Consulte `docs/plano_execucao.md` antes de qualquer execução.
