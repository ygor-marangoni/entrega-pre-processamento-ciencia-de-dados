# Diário de experimentos — Trabalho 4

## Etapa 0 — Auditoria do repositório

- Situação: concluída antes da criação deste diretório.
- Fonte candidata confirmada: `base_amostra_10000_analise.csv`.
- Evidência: os 10.000 registros e todos os campos foram conferidos contra a
  base final do Trabalho 1; os valores são originais e não ponderados.
- Restrição registrada: `ROW_ID_AMOSTRA`, `SK_ID_CURR` e `TARGET` não poderão
  participar do Apriori.
- Base excluída como entrada direta: `base_clusterizacao_final.csv`, pois usa
  Min-Max e multiplicação por raiz do peso nos atributos numéricos.

## Etapa 1 — Estrutura inicial

- Situação: documentação mínima criada.
- Não houve processamento de dados, discretização, seleção de atributos, uso
  do WEKA ou execução de Apriori.

## Etapa 2 — Análise de candidatos

- Situação: concluída; a escolha dos oito atributos permanece sujeita a
  aprovação expressa.
- Foram examinados 13 candidatos em 10.000 registros, sem alterar a base de
  origem. Foram geradas estatísticas descritivas, frequências categóricas,
  histogramas e boxplots.
- Recomendação: `AMT_CREDIT`, `AMT_INCOME_TOTAL`, `AGE_YEARS`, `CNT_CHILDREN`,
  `FLAG_OWN_CAR_COD`, `NAME_FAMILY_STATUS_COD`, `SER_CREDITOS_ATIVOS` e
  `PREV_TAXA_REJEICAO`.
- Principais descartes: `CREDIT_INCOME_RATIO` é derivado de crédito e renda;
  `SER_DIVIDA_ATRASADA` possui 98,80% de zeros; `REGION_RATING_CLIENT` tem
  apenas três níveis e 74,16% na categoria dominante.
- Foi identificada correlação de Spearman de 0,7657 entre
  `SER_CREDITOS_ATIVOS` e `SER_QTDE_EMPRESTIMOS` e de 0,5488 entre
  `PREV_QTDE_TENTATIVAS` e `PREV_TAXA_REJEICAO`, apoiando a retenção de uma
  variável de cada par para reduzir redundância.
- Limitações observadas: renda tem assimetria muito alta (99,018857) e máximo
  de R$ 117.000.000; a categoria `Unknown` de estado familiar aparece uma vez
  (0,01%) e exigirá decisão explícita na discretização; a taxa de rejeição tem
  67,71% de zeros semânticos.
- A geração dos gráficos emitiu avisos não bloqueantes do cache externo do
  Matplotlib sem comprometer os três PNGs; também há aviso de depreciação de
  opção de boxplot que não altera os resultados atuais.

## Etapa 3 — Projeto das faixas de discretização

- Situação: concluída; aplicação das faixas na base final ainda depende de
  aprovação expressa.
- A autorização para iniciar esta etapa foi registrada como aprovação dos oito
  atributos recomendados na Etapa 2, exclusivamente para o projeto das faixas.
- Foram simuladas 27 categorias para os oito atributos recomendados, apenas em
  memória, sobre a mesma amostra original de 10.000 registros.
- Crédito e renda usam os quartis reais P25, P50 e P75. Os cortes de renda
  evitam intervalos de mesma largura, inadequados diante do máximo de
  R$ 117.000.000 e da forte assimetria observada.
- As cinco faixas semânticas de idade variaram de 12,18% a 26,60% da amostra.
- `CNT_CHILDREN`, `SER_CREDITOS_ATIVOS` e `PREV_TAXA_REJEICAO` receberam
  rótulos para seus zeros reais, respectivamente `SEM_FILHOS`,
  `SEM_CREDITOS_ATIVOS` e `SEM_REJEICAO_PREVIA`.
- `FLAG_OWN_CAR_COD` foi recuperado como `SEM_CARRO`/`COM_CARRO`.
- O único registro `Unknown` de estado familiar foi agrupado com separado e
  viúvo para evitar uma categoria com 0,01% da amostra.
- Validações: oito atributos; 10.000 rótulos válidos por atributo; nenhuma
  categoria ausente; nenhuma categoria abaixo de 1% ou 5%; nenhum zero
  numérico usado como categoria.

## Etapa 4 — Geração da base discretizada

- Situação: concluída.
- Foram gerados `data/discretizadas/base_apriori_discretizada.csv` e o ARFF
  auxiliar de mesmo nome, a partir das faixas aprovadas na Etapa 3.
- A base possui exatamente 10.000 registros e oito atributos nominais:
  `FAIXA_CREDITO`, `FAIXA_RENDA`, `FAIXA_IDADE`, `CATEGORIA_FILHOS`,
  `POSSE_CARRO`, `SITUACAO_FAMILIAR`, `FAIXA_CREDITOS_ATIVOS` e
  `FAIXA_TAXA_REJEICAO`.
- Não há `SK_ID_CURR`, `TARGET`, `ROW_ID_AMOSTRA`, `cluster`, pesos,
  normalização Min-Max, raiz de peso, valores vazios, marcadores ausentes ou
  zero numérico como categoria.
- A ordem foi preservada pela transformação indexada da amostra de origem. A
  sequência original de `ROW_ID_AMOSTRA`, mantida apenas na origem auxiliar,
  gerou SHA-256 `2ec321e75e28488b83455ba9b64a2ec00fe9470188b0bc6060d837aa56272f5d`
  quando serializada com separador `|`.
- O ARFF foi validado sem WEKA: possui oito declarações nominais, 10.000 linhas
  de dados e nenhum marcador `?`.

## Etapa 5 — Validação da base Apriori

- Situação: concluída e aprovada em todos os dez controles registrados em
  `resultados/discretizacao/validacao_base.csv`.
- A comparação independente recompôs as categorias a partir da amostra de
  origem e confirmou a mesma sequência de 10.000 registros no CSV salvo.
- Foram calculadas as frequências dos 27 itens nominais. Cada atributo soma
  exatamente 10.000 ocorrências; os suportes individuais variam de 10,34%
  (`CATEGORIA_FILHOS=DOIS_OU_MAIS_FILHOS`) a 73,04%
  (`SITUACAO_FAMILIAR=CASADO_OU_UNIAO_CIVIL`).
- A base continua sem valores ausentes, campos protegidos, atributos numéricos
  ou representações numéricas de zero.
- Nenhum WEKA ou Apriori foi executado nesta etapa.

## Etapa 6 — Auditoria das opções do Apriori no WEKA

- Situação: concluída.
- A consulta real à classe `weka.core.Version` confirmou WEKA 3.8.7 no JAR
  `C:\Program Files\Weka-3-8-7\weka.jar`; o Java em uso foi OpenJDK Temurin
  17.0.20.
- A ajuda real de `weka.associations.Apriori -h` confirmou `-N`, `-M`, `-U`,
  `-D`, `-I` e `-Z`, com os padrões respectivos de 10 regras, suporte mínimo
  inferior 0,1, superior 1,0, delta 0,05, itemsets desativados e zero não
  tratado como ausente.
- Não há opção nativa listada para limitar regras a exatamente três itens.
  A saída integral será preservada e o tamanho será verificado posteriormente
  pela soma dos itens de antecedente e consequente.
- Nenhuma base foi fornecida ao Apriori nesta etapa; não houve mineração,
  itemsets ou regras geradas.

## Etapa 7 — Busca do suporte (interrompida antes de executar)

- Situação: bloqueada por incompatibilidade metodológica confirmada na
  implementação real do WEKA 3.8.7.
- A opção obrigatória `-Z` trata como ausente o primeiro valor de **todo**
  atributo nominal, independentemente do texto que representa a categoria.
- Os primeiros valores declarados no ARFF atual são categorias reais, como
  `CREDITO_ALTO`, `COM_CARRO` e `CASADO_OU_UNIAO_CIVIL`. Minerar com `-Z`
  eliminaria essas observações e distorceria os suportes.
- Nenhum teste de suporte, itemset ou regra foi executado; portanto, não há
  resultados artificiais ou tentativas a preservar nesta etapa.
- É necessária orientação explícita para conciliar `treatZeroAsMissing=true`
  com os oito atributos nominais sem transformar categorias reais em ausentes.
